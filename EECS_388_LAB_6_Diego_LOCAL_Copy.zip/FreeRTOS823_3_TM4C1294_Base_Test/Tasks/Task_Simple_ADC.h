/*
 * Task_Simple_ADC.h
 *
 *  Created on: Apr 9, 2016
 *      Author: dsolizca
 */

#ifndef TASKS_TASK_SIMPLE_ADC_H_
#define TASKS_TASK_SIMPLE_ADC_H_

#include "queue.h"

extern QueueHandle_t myQ;


#endif /* TASKS_TASK_SIMPLE_ADC_H_ */
